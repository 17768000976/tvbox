/* empty css              */import{c as r}from"./VAvatar-BxPiyHNt.js";const a=r("v-spacer","div","VSpacer");export{a as V};
